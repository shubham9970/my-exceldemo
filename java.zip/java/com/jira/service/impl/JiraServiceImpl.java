package com.jira.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jira.dto.Fields;
import com.jira.dto.Histories;
import com.jira.dto.Issuelinks;
import com.jira.dto.Issues;
import com.jira.dto.Items;
import com.jira.dto.LoggedWorklog;
import com.jira.dto.MainDto;
import com.jira.dto.Transition;
import com.jira.dto.Worklogs;
import com.jira.service.ExcelService;
import com.jira.service.JiraService;
import com.jira.util.JiraFIeld;

@Service
public class JiraServiceImpl implements JiraService {

	@Autowired
	private ExcelService excelService;

	@Autowired
	private RestTemplate restTemplate;
	public static String sprintName = "sprint_name";
	private final String excelPath = "C:\\\\Users\\\\temp\\\\Downloads\\\\SprintIssueReport" + sprintName + ".xlsx";
	private static XSSFWorkbook wb;
	private static FileOutputStream fos;
	private static Map<Object, Object> issueMap = new LinkedHashMap<Object, Object>();
	static int count = 0;

	@Override
	public String createIssueData() {
		int temp = 13;
		try {
			wb = new XSSFWorkbook();
			fos = new FileOutputStream(new File(excelPath));
			excelService.createExcelFile(excelPath, wb, fos);
			excelService.writeIssuesExcelHeader(wb);
			HttpHeaders headers = createHttpHeaders("username", "password");
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			for (int i = 0; i < 8; i++) {
				temp = temp + 2;

				sprintName = sprintName + temp;
				String issueFieldUrl = "https://host/rest/api/2/search?jql=Sprint=" + sprintName;
				System.out.println();
				System.out.println(" ##############################################################");
				ResponseEntity<String> fieldResponse = restTemplate.exchange(issueFieldUrl, HttpMethod.GET, entity,
						String.class);

				ObjectMapper mapper = new ObjectMapper();
				MainDto readValue = mapper.readValue(fieldResponse.getBody(), MainDto.class);
				jsonIssueToObjectIssue(readValue);
				sprintName = "sprint1";
			}
			try {
				// excelService.writeTransitionExcelHeader(wb);
				// transitionToObject(mainDto);
				wb.write(fos);
				fos.flush();
				fos.close();
				System.out.println("Excel written successfully..");

			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (Exception eek) {
			System.out.println("*** Exception: " + eek.getMessage() + eek.toString());
		}
		return "Operation is successful";
	}

	/*
	 * private void transitionToObject(MainDto readValue) { List<Issues> issues =
	 * readValue.getIssues(); issues.forEach(issuesList -> {
	 * issueMap.put(JiraFIeld.Sprint_Name, sprintName); String issueNumber =
	 * issuesList.getIssueName(); String transiton = getTransitons(issueNumber);
	 * issueMap.put(JiraFIeld.Sprint_Name, sprintName);
	 * issueMap.put(JiraFIeld.Issue_Number, issueNumber);
	 * issueMap.put(JiraFIeld.Transitions, transiton);
	 * excelService.writeTransitionExcelBody(issueMap, wb);
	 * 
	 * 
	 * });
	 * 
	 * }
	 */

	private HttpHeaders createHttpHeaders(final String user, final String password) {
		String notEncoded = user + ":" + password;
		String encodedAuth = "Basic " + Base64.getEncoder().encodeToString(notEncoded.getBytes());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", encodedAuth);
		return headers;
	}

	private void jsonIssueToObjectIssue(final MainDto mainDto) throws Exception {

		List<Issues> issues = mainDto.getIssues();

		issues.forEach(issuesList -> {
			String issueNumber = issuesList.getIssueName();

			String currentAssignee = getCurrentAssignees(issuesList.getFields());
			String[] role = getRoles(issuesList.getFields().getRoles());
			System.out.println(role[0] + " " + role[1] + " " + role[2]);
			String[] logged = getLogged(role, issueNumber);
			String diff = logged[3];
			String typeOfIssue = issuesList.getFields().getIssuetype().getTypeOfIssue();
			LocalDate createdDate = stringToDate(issuesList.getFields().getCreated());
			String currentStatus = issuesList.getFields().getStatus().getIsuueStatus();
			String sprintState = findSprintState(issuesList.getFields().getSprintStatus());
			Double storyPoints = issuesList.getFields().getStoryPoint();
			String linkedIssues = getLinkedIssues(issuesList.getFields());
			String transiton = getTransitons(issueNumber);
			String priority = getPriority(issuesList.getFields());
			String severity = getSeverity(issuesList.getFields());
			String fixVersion = getFixVersion(issuesList.getFields());

			issueMap.put(JiraFIeld.Sprint_Name, sprintName);
			issueMap.put(JiraFIeld.Issue_Number, issueNumber);
			issueMap.put(JiraFIeld.Priority, priority);
			issueMap.put(JiraFIeld.Severity, severity);
			issueMap.put(JiraFIeld.Current_Assignee, currentAssignee);
			issueMap.put(JiraFIeld.Developer, role[0]);
			issueMap.put(JiraFIeld.Dev_Logged, logged[0]);
			issueMap.put(JiraFIeld.CR, role[1]);
			issueMap.put(JiraFIeld.CR_Logged, logged[1]);
			issueMap.put(JiraFIeld.QA, role[2]);
			issueMap.put(JiraFIeld.QA_Logged, logged[2]);
			issueMap.put(JiraFIeld.Time_Diffrence, diff);
			issueMap.put(JiraFIeld.Type_of_Issue, typeOfIssue);
			issueMap.put(JiraFIeld.Created_Date, createdDate);
			issueMap.put(JiraFIeld.Current_Status, currentStatus);
			issueMap.put(JiraFIeld.Sprint_State, sprintState);
			issueMap.put(JiraFIeld.Story_Points, storyPoints);
			issueMap.put(JiraFIeld.Linked_Issues, linkedIssues);

			issueMap.put(JiraFIeld.Fix_Version, fixVersion);
			issueMap.put(JiraFIeld.Transitions, transiton);
			System.out.println(issueMap);

			try {

				System.out.println(issueNumber + " " + count++);

				excelService.writeIssuesExcelBody(issueMap, wb);

			} catch (IOException e) {
				e.printStackTrace();
			}

		});

	}

	private String[] getLogged(String[] role, final String issue) {
		System.out.println("in logged method................... ");
		int totalTime = 0;
		int overAllTime=0;
		boolean check = false;
		String[] timeLog = new String[4];
		try {
		
			String worklogUrl = "https://Host/rest/api/2/issue/" + issue +"/worklog/?expand=changelog";
			HttpHeaders headers = createHttpHeaders("username", "password");
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			ObjectMapper mapper = new ObjectMapper();
			ResponseEntity<String> worklogResponse = restTemplate.exchange(worklogUrl, HttpMethod.GET, entity,
					String.class);
			LoggedWorklog readWorklog = mapper.readValue(worklogResponse.getBody(), LoggedWorklog.class);
			List<Worklogs> worklogs = readWorklog.getWorklogs();
			if (worklogs != null && role != null) {
				if (!(role[0].equals("") && role[1].equals("") && role[2].equals(""))) {
					
					int combinedRolesTime = 0;
					
					for (int i = 0; i < role.length; i++) {
						if ( role[i] != null) {
							check=true;
							if(role[0].equals(role[1])&&role[1].equals(role[2])) 
								i=i+2;
							else if(role[0].equals(role[1])) {
								if(role[0].equals("")&&role[0].equals(""))
								i=i+2;
								else
									i++;
							}
							else if(role[1].equals(role[2])) {
								if(role[1].equals("")&&role[1].equals(""))
									i=i+2;
									else
										i++;
							}
							else if(role[0].equals(role[2])) {
								if(role[0].equals("")&&role[2].equals(""))
									i=i+2;
									else
										i++;
							}
								
							
							for (int j = 0; j < worklogs.size(); j++) {
								if (worklogs.get(j) != null) {
									Worklogs w = worklogs.get(j);
									if (w.getUpdateAuthor().getName().contains(role[i])&& !role[i].equals("")) {
										totalTime = totalTime + Integer.parseInt(w.getTimeSpent());
									}
								}
							}
						
							combinedRolesTime = totalTime + combinedRolesTime;
							double totalTimeByRole =((totalTime / 60.0)/60);
							String str=totalTimeByRole+"";
							if(str.length()>5)
							 timeLog[i]=str.substring(0,4);
							else
								timeLog[i]=str;
							
							System.out.println(issue + " " + role[i] + " " + timeLog[i]);
							totalTime = 0;
						}
					}
					for(int i=0;i<worklogs.size();i++) {
						overAllTime=overAllTime+Integer.parseInt(worklogs.get(i).getTimeSpent());
						
					}
					if (timeLog != null && overAllTime+"" != null&& check) {
						System.out.println("###########"  +overAllTime );
						 overAllTime = overAllTime/60;
						combinedRolesTime = (combinedRolesTime / 60);
						double timeDiff = ((overAllTime - combinedRolesTime)/60.0);
						
						System.out.println("time diffrence  = " + timeDiff);
						String totalTimeDifference=timeDiff+"";
						
						if (totalTimeDifference.length()>5)
							timeLog[3] = totalTimeDifference.substring(0, 4);
						else
							timeLog[3] = totalTimeDifference;
					}

					return timeLog;
				}
			}
		} catch (Exception eek) {
			System.out.println("** Exception: in Worklog " + eek.getMessage());
		}

		return new String[] { "", "", "", "" };
	}

	private String getFixVersion(final Fields fields) {
		if (!fields.getFixVersions().isEmpty()) {
			System.out.println("fix version method");
			if (fields.getFixVersions().get(0) != null) {
				if (fields.getFixVersions().get(0).getName().contains("OMS_")) {
					String version = fields.getFixVersions().get(0).getName().substring(4);
					return version;
				} else
					return fields.getFixVersions().get(0).getName().toString();

			}
		}
		return "";
	}

	private String getSeverity(Fields fields) {

		if (fields.getSeverity() != null) {
			return fields.getSeverity().getValue();
		} else
			return "";
	}

	private String getPriority(Fields fields) {

		if (fields.getPriority() != null) {
			return fields.getPriority().getName();
		} else
			return "";
	}

	private String getCurrentAssignees(final Fields fields) {

		if (fields.getAssignee() != null) {
			String[] string = fields.getAssignee().getName().split("@");
			return string[0];
		} else
			return null;
	}

	private String[] getRoles(final String[] rolesArray) {
		String[] roles = new String[3];
		if (rolesArray != null) {
			for (int i = 0; i < rolesArray.length - 1; i++) {
				if (rolesArray[i] != null && rolesArray[i].contains("10001")) {
					int open = rolesArray[i].indexOf("(") + 1;
					int close = rolesArray[i].indexOf(")");
					String[] string = rolesArray[i].substring(open, close).split("@");
					if (string[0].equals("null"))
						string[0] = "";
					roles[0] = string[0];
				}

				if (rolesArray[i] != null && rolesArray[i].contains("10455")) {
					int open = rolesArray[i].indexOf("(") + 1;
					int close = rolesArray[i].indexOf(")");
					String[] string = rolesArray[i].substring(open, close).split("@");
					if (string[0].equals("null"))
						string[0] = "";
					roles[1] = string[0];

				}

				if (rolesArray[i] != null && rolesArray[i].contains("10454")) {
					int open = rolesArray[i].indexOf("(") + 1;
					int close = rolesArray[i].indexOf(")");
					String[] string = rolesArray[i].substring(open, close).split("@");
					if (string[0].equals("null"))
						string[0] = "";
					roles[2] = string[0];

				}

			}
			return roles;

		}

		return new String[] { "", "", "" };

	}

	public LocalDate stringToDate(final String stringDate) {
		String[] stringDateArray = stringDate.split("T");
		LocalDate result = LocalDate.parse(stringDateArray[0]);
		return result;
	}

	private String findSprintState(final String[] sprintStatus) {
		if (sprintStatus.length > 0 && sprintStatus[sprintStatus.length - 1].contains(sprintName)
				&& sprintStatus[sprintStatus.length - 1].contains("ACTIVE"))
			return "ACTIVE";
		else
			return "CLOSED";
	}

	private String getLinkedIssues(final Fields fields) {
		String linkedIssues = "";
		List<Issuelinks> issuelinks = fields.getIssueLinks();
		if (fields.getIssueLinks() != null) {
			for (int i = 0; i < issuelinks.size(); i++) {
				if (issuelinks.get(i).getOutwardIssues() != null)
					linkedIssues = linkedIssues + " " + issuelinks.get(i).getOutwardIssues().getIssueName();
			}
		}
		return linkedIssues;
	}

	private String getTransitons(final String issue) {

		String transition = "";
		try {
			String issueTransitionUrl = "https://host/rest/api/2/issue/" + issue
					+ "?fields=status&expand=changelog";

			HttpHeaders headers = createHttpHeaders("username", "password");
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			ObjectMapper mapper = new ObjectMapper();
			ResponseEntity<String> transitionResponse = restTemplate.exchange(issueTransitionUrl, HttpMethod.GET,
					entity, String.class);
			Transition readTransitions = mapper.readValue(transitionResponse.getBody(), Transition.class);

			List<Histories> histories = readTransitions.getChangelog().getHistories();
			// String[] logged=getLogged(readTransitions.getFields().getWorklog());
			for (Histories history : histories) {

				List<Items> ListOfItems = history.getItems();
				for (Items itemArray : ListOfItems) {
					if (itemArray.getFromString() != null && itemArray.getOtherString() != null
							&& itemArray.getField().equals("status")) {
						transition = transition.concat(itemArray.getFromString().trim() + "->"
								+ itemArray.getOtherString().trim() + "->" + history.getCreated().trim() + ",");

						System.out.println();
					}
				}
			}

		} catch (Exception eek) {
			System.out.println("** Exception: " + eek.getMessage());
		}
		return transition;
	}

}
