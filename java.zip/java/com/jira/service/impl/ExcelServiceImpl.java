package com.jira.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.jira.service.ExcelService;
import com.jira.util.JiraFIeld;

@Service
public class ExcelServiceImpl implements ExcelService {

	private static int rowNum = 0;
	private static int transitionRowNum = 0;
	private static Sheet sheet;
	private static Row row;

	public void createExcelFile(final String excelPath, Workbook wb, FileOutputStream fos) {
		try {
			File f = new File(excelPath);
			if (!f.exists()) {
				f.createNewFile();
				System.out.println("File doesn't exist, so created!");
				sheet = wb.createSheet("Project_Open_Issues_Count");
			} else {
				f.delete();
				f.createNewFile();
				System.out.println("File doesn't exist, so created!");
				sheet = wb.createSheet("Project_Open_Issues_Count");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void writeIssuesExcelBody(final Map<Object, Object> issueMap, Workbook wb) {

		Collection<Object> values = issueMap.values();
		List<Object> listValues = new ArrayList<Object>(values);
		String transString = (String) issueMap.get(JiraFIeld.Transitions);
		String[] arryaTransitions = transString.split(",");

		for (String transition : arryaTransitions) {
			int cellNum = 0;
			row = sheet.createRow(rowNum++);
			for (int i = 0; i < listValues.size()-1 ; i++) {

				if (listValues.get(i) == null) {
					Cell cell = row.createCell(cellNum++);
					cell.setCellValue("");
				} else {
					Cell cell = row.createCell(cellNum++);
					cell.setCellValue(listValues.get(i).toString());
				}
			}

			if (transition != null) {

				String[] statusString = transition.split("->");
				for (int i = 0; i < statusString.length-1; i++) {
					Cell cell = row.createCell(cellNum++);
					cell.setCellValue(statusString[i]);
					if (i == 1) {
						
						String[] time = statusString[2].split("T");
						String exactTime = time[1].substring(0, 8);
						cell = row.createCell(cellNum++);
						cell.setCellValue(time[0].toString());
						cell = row.createCell(cellNum++);
						cell.setCellValue(exactTime.toString());
					}
				}
			}
			
					}


	}

	public void writeIssuesExcelHeader(Workbook wb) {

		int cellNum = 0;
		Font headerFont = wb.createFont();
		headerFont.setBold(true);
		CellStyle headerCellStyle = wb.createCellStyle();
		headerCellStyle.setFont(headerFont);
		row = sheet.createRow(rowNum++);
		JiraFIeld[] jiraFiledArray = JiraFIeld.values();
		for (Object object : jiraFiledArray) {
			if (!(object.toString().equals(JiraFIeld.Transitions.toString()))) {
				Cell cell = row.createCell(cellNum++);
				cell.setCellValue(object.toString());
				cell.setCellStyle(headerCellStyle);
			} else {
				Cell cell = row.createCell(cellNum++);
				cell.setCellValue("created");
				cell.setCellStyle(headerCellStyle);
			}
		}
	}

	public void writeTransitionExcelHeader(Workbook wb) {
		sheet = wb.createSheet("Split_Transions");
		int cellNum = 0;
		Font headerFont = wb.createFont();
		headerFont.setBold(true);
		CellStyle headerCellStyle = wb.createCellStyle();
		headerCellStyle.setFont(headerFont);
		row = sheet.createRow(transitionRowNum++);
		JiraFIeld[] jiraFiledArray = JiraFIeld.values();
		for (int i = 0; i < jiraFiledArray.length; i++) {
			if (JiraFIeld.Sprint_Name.equals(jiraFiledArray[i]) || JiraFIeld.Issue_Number.equals(jiraFiledArray[i])
					|| JiraFIeld.From.equals(jiraFiledArray[i]) || JiraFIeld.To.equals(jiraFiledArray[i])) {
				Cell cell = row.createCell(cellNum++);
				cell.setCellValue(jiraFiledArray[i].toString());
				cell.setCellStyle(headerCellStyle);
			}
		}

		System.out.println("succefully write transion header");
	}

	@Override
	public void writeTransitionExcelBody(Map<Object, Object> issueMap, XSSFWorkbook wb) {

		boolean tempValue = true;
		String transString = (String) issueMap.get(JiraFIeld.Transitions);
		String[] arryaTransitions = transString.split(",");
		for (String transition : arryaTransitions) {
			int cellNum = 2;
			if (transition != null && !transition.isEmpty()) {
				if (tempValue) {
					int cellNumTemp = 0;
					row = sheet.createRow(transitionRowNum++);
					Cell cell = row.createCell(cellNumTemp++);
					cell.setCellValue((String) issueMap.get(JiraFIeld.Sprint_Name));
					Cell cell2 = row.createCell(cellNumTemp++);
					cell2.setCellValue((String) issueMap.get(JiraFIeld.Issue_Number));
					tempValue = false;
				}
				row = sheet.createRow(transitionRowNum++);
				String[] statusString = transition.split("->");
				for (int i = 0; i < statusString.length; i++) {

					Cell cell2 = row.createCell(cellNum++);
					cell2.setCellValue(statusString[i]);
				}
			}

		}
	}
}
