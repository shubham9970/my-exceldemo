package com.jira.service;

public interface JiraService {

	String createIssueData();

}
