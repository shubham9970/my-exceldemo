package com.jira.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public interface ExcelService {
	 void createExcelFile(String excelPath,final Workbook wb,final FileOutputStream fos);

	 void writeIssuesExcelHeader(Workbook wb) throws IOException;

	 void writeIssuesExcelBody(Map<Object,Object> issueMap, Workbook wb) throws IOException;

	

	void writeTransitionExcelHeader(Workbook wb);

	void writeTransitionExcelBody(Map<Object, Object> issueMap, XSSFWorkbook wb);
}
