package com.jira.util;

public enum JiraFIeld {

	Sprint_Name, Issue_Number, Priority,Severity,Current_Assignee, 
	Developer,Dev_Logged,CR,CR_Logged,QA,QA_Logged,Time_Diffrence,Type_of_Issue, Created_Date, Current_Status, Sprint_State,
	Story_Points, Linked_Issues,Fix_Version,From, To,Transitions,Time

}
