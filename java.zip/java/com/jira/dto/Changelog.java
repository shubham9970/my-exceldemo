package com.jira.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Changelog {
	
	@JsonProperty("histories")
	private List<Histories> histories;

	public List<Histories> getHistories() {
		return histories;
	}

	public void setHistories(List<Histories> histories) {
		this.histories = histories;
	}

	

	

}
