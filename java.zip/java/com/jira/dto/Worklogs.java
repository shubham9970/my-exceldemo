package com.jira.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Worklogs {

	@JsonProperty("timeSpentSeconds")
	private String timeSpent;
	
	@JsonProperty("updateAuthor")
	private UpdateAuthor updateAuthor;
	

	public UpdateAuthor getUpdateAuthor() {
		return updateAuthor;
	}

	public void setUpdateAuthor(UpdateAuthor updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

	public String getTimeSpent() {
		return timeSpent;
	}

	public void setTimeSpent(String timeSpent) {
		this.timeSpent = timeSpent;
	}

	
}
