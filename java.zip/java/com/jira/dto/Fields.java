package com.jira.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Fields {
	@JsonProperty("timetracking")
	private Timetracking timetracking;
	
	
	@JsonProperty("assignee")
	private Assignee assignee;
	@JsonProperty("created")
	private String created;
	@JsonProperty("status")
	private Status status;
	@JsonProperty("customfield_10402")
	private double storyPoint;
	@JsonProperty("issuelinks")
	private List<Issuelinks> issueLinks;
	@JsonProperty("customfield_12201")
	private String[] roles;
	@JsonProperty("customfield_10700")
	private Severity severity;

	@JsonProperty("priority")
	private Priority priority;

	@JsonProperty("fixVersions")
	private List<FixVersions> fixVersions;

	public Timetracking getTimetracking() {
		return timetracking;
	}

	public void setTimetracking(Timetracking timetracking) {
		this.timetracking = timetracking;
	}

	

	public List<FixVersions> getFixVersions() {
		return fixVersions;
	}

	public void setFixVersions(List<FixVersions> fixVersions) {
		this.fixVersions = fixVersions;
	}

	public Severity getSeverity() {
		return severity;
	}

	public void setSeverity(Severity severity) {
		this.severity = severity;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public String[] getRoles() {
		return roles;
	}

	public void setRoles(String[] roles) {
		this.roles = roles;
	}

	@JsonProperty("customfield_10404")
	private String sprintStatus[];

	@JsonProperty("issuetype")
	private Issuetype issuetype;

	public Assignee getAssignee() {
		return assignee;
	}

	public void setAssignee(Assignee assignee) {
		this.assignee = assignee;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public double getStoryPoint() {
		return storyPoint;
	}

	public void setStoryPoint(double storyPoint) {
		this.storyPoint = storyPoint;
	}

	public List<Issuelinks> getIssueLinks() {
		return issueLinks;
	}

	public void setIssueLinks(List<Issuelinks> issueLinks) {
		this.issueLinks = issueLinks;
	}

	public String[] getSprintStatus() {
		return sprintStatus;
	}

	public void setSprintStatus(String[] sprintStatus) {
		this.sprintStatus = sprintStatus;
	}

	public Issuetype getIssuetype() {
		return issuetype;
	}

	public void setIssuetype(Issuetype issuetype) {
		this.issuetype = issuetype;
	}

}
