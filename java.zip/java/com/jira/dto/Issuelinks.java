package com.jira.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Issuelinks {
	@JsonProperty("outwardIssue")
	private OutwardIssues outwardIssues;

	public OutwardIssues getOutwardIssues() {
		return outwardIssues;
	}

	public void setOutwardIssues(OutwardIssues outwardIssues) {
		this.outwardIssues = outwardIssues;
	}

}
