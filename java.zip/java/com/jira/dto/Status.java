package com.jira.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Status implements Serializable {

	@JsonProperty("name")
	private String isuueStatus;

	public String getIsuueStatus() {
		return isuueStatus;
	}

	public void setIsuueStatus(String isuueStatus) {
		this.isuueStatus = isuueStatus;
	}
	
}
