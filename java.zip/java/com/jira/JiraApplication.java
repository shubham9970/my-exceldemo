package com.jira;

import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class JiraApplication {

	public static void main(String[] args) throws URISyntaxException, InterruptedException, ExecutionException {
		SpringApplication.run(JiraApplication.class, args);

	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
